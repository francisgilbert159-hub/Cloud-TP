import os
import time
import uuid

import boto3
import psycopg
from botocore.exceptions import ClientError
from flask import Flask, Response, jsonify, request

DATABASE_URL = os.environ["DATABASE_URL"]
BUCKET = os.environ.get("S3_BUCKET", "fichiers")

s3 = boto3.client(
    "s3",
    endpoint_url=os.environ["S3_ENDPOINT"],
    aws_access_key_id=os.environ["S3_ACCESS_KEY"],
    aws_secret_access_key=os.environ["S3_SECRET_KEY"],
    region_name="us-east-1",
)
app = Flask(__name__)


def connexion():
    return psycopg.connect(DATABASE_URL, autocommit=True)


def initialiser():
    """Crée la table et le bucket, en attendant que la base et le stockage répondent."""
    for _ in range(30):
        try:
            with connexion() as c:
                c.execute(
                    """CREATE TABLE IF NOT EXISTS fichiers (
                           id SERIAL PRIMARY KEY,
                           nom TEXT NOT NULL,
                           cle TEXT NOT NULL,
                           taille INTEGER NOT NULL,
                           depose_le TIMESTAMP DEFAULT now())"""
                )
            try:
                s3.head_bucket(Bucket=BUCKET)
            except ClientError:
                s3.create_bucket(Bucket=BUCKET)
            print("Base et stockage prêts", flush=True)
            return
        except Exception as erreur:
            print(f"En attente des services : {erreur}", flush=True)
            time.sleep(2)
    raise RuntimeError("Base ou stockage injoignable")


@app.get("/")
def accueil():
    return jsonify(message="API fil rouge", version="2.0",
                   binome=os.environ.get("BINOME", "inconnu"))


@app.get("/sante")
def sante():
    with connexion() as c:
        c.execute("SELECT 1")
    s3.head_bucket(Bucket=BUCKET)
    return jsonify(base="ok", stockage="ok")


@app.post("/fichiers")
def deposer():
    fichier = request.files.get("fichier")
    if fichier is None or fichier.filename == "":
        return jsonify(erreur="champ 'fichier' manquant"), 400
    donnees = fichier.read()
    cle = f"{uuid.uuid4().hex}-{fichier.filename}"
    s3.put_object(Bucket=BUCKET, Key=cle, Body=donnees,
                  ContentType=fichier.mimetype or "application/octet-stream")
    with connexion() as c:
        ligne = c.execute(
            "INSERT INTO fichiers (nom, cle, taille) VALUES (%s, %s, %s) RETURNING id",
            (fichier.filename, cle, len(donnees)),
        ).fetchone()
    return jsonify(id=ligne[0], nom=fichier.filename, cle=cle, taille=len(donnees)), 201


@app.get("/fichiers")
def lister():
    with connexion() as c:
        lignes = c.execute(
            "SELECT id, nom, cle, taille, depose_le FROM fichiers ORDER BY id"
        ).fetchall()
    return jsonify([
        {"id": l[0], "nom": l[1], "cle": l[2], "taille": l[3],
         "depose_le": l[4].isoformat()}
        for l in lignes
    ])


@app.get("/fichiers/<int:ident>")
def telecharger(ident):
    with connexion() as c:
        ligne = c.execute("SELECT cle FROM fichiers WHERE id = %s", (ident,)).fetchone()
    if ligne is None:
        return jsonify(erreur="fichier introuvable"), 404
    objet = s3.get_object(Bucket=BUCKET, Key=ligne[0])
    return Response(objet["Body"].read(), mimetype=objet["ContentType"])


initialiser()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
