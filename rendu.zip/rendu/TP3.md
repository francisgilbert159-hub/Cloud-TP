# TP 3 · Séance 4 — Application multi-services avec Docker Compose

**Binôme :** Diomande-Mohamed
**Environnement :** VM `ubuntu-srv` (Ubuntu 26.04 LTS, VirtualBox), Docker et Docker Compose
**Application :** API Flask + PostgreSQL 17 + MinIO (stockage objet compatible S3)

---

## Partie 0 — Préparer la VM

La VM est éteinte, on lui donne 3 Go de RAM et on ajoute la redirection de la console MinIO.

**PowerShell (hôte)**
```powershell
$env:Path += ";C:\Program Files\Oracle\VirtualBox"
VBoxManage modifyvm ubuntu-srv --memory 3072
VBoxManage modifyvm ubuntu-srv --natpf1 "minio,tcp,127.0.0.1,9001,,9001"
VBoxManage modifyvm ubuntu-srv --natpf1 "api,tcp,127.0.0.1,5000,,5000"
VBoxManage startvm ubuntu-srv --type headless
ssh -p 2222 etudiant@127.0.0.1
```

La règle `api` existait déjà (TP 2) : l'erreur « A NAT rule of this name already exists » est attendue.

**Vérification dans la VM**
```bash
free -h
```
```
               total        used        free      shared  buff/cache   available
Mem:           2,6Gi       416Mi       1,6Gi       1,1Mi       708Mi       2,2Gi
```

Les fichiers du TP (zip) ont été envoyés dans la VM avec `scp`, puis décompressés dans `~/tp3`. Les conteneurs du TP 2 ont été supprimés et les images `postgres:17` et `cgr.dev/chainguard/minio:latest` récupérées.

---

## Partie 1 — Décrire et lancer l'application

### 1.1 Fichier Compose

`docker-compose.yml` décrit trois services : `api` (construit depuis `./api`), `db` (`postgres:17`, avec healthcheck et volume `db-data`) et `minio` (`cgr.dev/chainguard/minio`, volume `minio-data`, console sur le port 9001).

```bash
docker compose config -q
docker compose up -d --build
docker compose ps
```

Résultat : les trois services sont démarrés, `db` est `healthy`. Le réseau `tp3_default` et les volumes `tp3_db-data` et `tp3_minio-data` sont créés.

```
NAME          IMAGE                             SERVICE   STATUS
tp3-api-1     tp3-api                           api       Up
tp3-db-1      postgres:17                       db        Up (healthy)
tp3-minio-1   cgr.dev/chainguard/minio:latest   minio     Up
```

```bash
curl -s http://localhost:5000
{"binome":"Diomande-Mohamed","message":"API fil rouge","version":"2.0"}

curl -s http://localhost:5000/sante
{"base":"ok","stockage":"ok"}

docker compose logs api | head -n 5
api-1  | Base et stockage prêts
```

### 1.2 Réseau et résolution de noms

```bash
docker network ls | grep tp3
docker network inspect tp3_default --format '{{range .Containers}}{{.Name}} {{.IPv4Address}}{{"\n"}}{{end}}'
docker compose exec api python -c "import socket; print(socket.gethostbyname('db'), socket.gethostbyname('minio'))"
nc -zv localhost 5432
docker compose exec db psql -U app -d app -c "SELECT version();"
```

```
68fa268dafbe   tp3_default   bridge   local
tp3-db-1 172.18.0.2/16
tp3-minio-1 172.18.0.3/16
tp3-api-1 172.18.0.4/16

172.18.0.2 172.18.0.3

nc: connect to localhost (127.0.0.1) port 5432 (tcp) failed: Connection refused

PostgreSQL 17.12 (Debian 17.12-1.pgdg13+1) on x86_64-pc-linux-gnu
```

### Questions

**Q1. Noms des conteneurs et préfixe `tp3`.**
Les conteneurs s'appellent `tp3-api-1`, `tp3-db-1` et `tp3-minio-1`. Le préfixe `tp3` est le nom du projet Compose, pris par défaut dans le nom du dossier (`~/tp3`). Le nom est de la forme `projet-service-numéro`.

**Q2. Adresses IP.**
Sur le réseau `tp3_default` (172.18.0.0/16) : `db` = 172.18.0.2, `minio` = 172.18.0.3, `api` = 172.18.0.4. Depuis l'API, le nom `db` se résout en 172.18.0.2 (et `minio` en 172.18.0.3) grâce au DNS interne de Compose, qui associe le nom du service à l'adresse du conteneur.

**Q3. Port 5432 depuis la VM.**
Non, le `nc` échoue (`Connection refused`) : le port 5432 n'est pas publié, seuls l'API (5000) et la console MinIO (9001) le sont. La base n'est joignable que depuis le réseau interne de Compose, donc seulement par l'API. C'est un bon choix de sécurité, car il réduit la surface d'attaque. C'est le même principe que les sous-réseaux privés du cloud : la base de données est placée dans un sous-réseau sans accès direct depuis Internet, et seule l'application peut l'atteindre.

**Q4. Healthcheck et `service_healthy`.**
`depends_on` seul attend uniquement que le conteneur soit démarré, pas que PostgreSQL accepte des connexions. Le healthcheck (`pg_isready`) teste que la base est réellement prête, et `condition: service_healthy` retarde le démarrage de l'API jusque-là. Sans eux, l'API pourrait démarrer avant la base et échouer à la connexion.

---

## Partie 2 — Vérifier la persistance

```bash
docker compose exec db psql -U app -d app -c "CREATE TABLE test (msg TEXT); INSERT INTO test VALUES ('bonjour TP3');"
docker compose exec db psql -U app -d app -c "SELECT * FROM test;"
docker compose down
docker compose ps -a
docker volume ls | grep tp3
docker compose up -d
docker compose exec db psql -U app -d app -c "SELECT * FROM test;"
```

Résultat : après `down` (sans `-v`), `docker compose ps -a` est vide, mais les volumes `tp3_db-data` et `tp3_minio-data` sont toujours listés. Après `up -d`, la ligne `bonjour TP3` est toujours présente.

```bash
docker volume inspect tp3_db-data --format '{{.Mountpoint}}'
/var/lib/docker/volumes/tp3_db-data/_data

sudo du -sh /var/lib/docker/volumes/tp3_db-data/_data
47M     /var/lib/docker/volumes/tp3_db-data/_data
```

`docker system df -v` indique 48,49 Mo pour `tp3_db-data` et 32,34 kB pour `tp3_minio-data`.

```bash
docker compose down -v
docker compose up -d
docker compose exec db psql -U app -d app -c "SELECT * FROM test;"
ERROR:  relation "test" does not exist
```

### Questions

**Q1. Tableau `down` / `down -v`.**

| Commande | Conteneurs | Réseau | Volumes | Ligne `bonjour TP3` |
|---|---|---|---|---|
| `docker compose down` | supprimés | supprimé | **conservés** | **conservée** |
| `docker compose down -v` | supprimés | supprimé | **supprimés** | **perdue** (base neuve) |

**Q2. Où sont les données ?**
Les données de PostgreSQL sont dans le dossier `/var/lib/docker/volumes/tp3_db-data/_data`, sur le disque de la VM, et non dans le conteneur. L'équivalent cloud d'un volume attaché à un serveur est le **stockage bloc** (par exemple Amazon EBS ou Azure Managed Disk) : un disque qui survit à la suppression de la machine.

**Q3. Pourquoi jamais `down -v` en production sans sauvegarde ?**
Parce que `down -v` supprime les volumes, donc les données (base, fichiers), de façon définitive. Sans sauvegarde, rien ne permet de les récupérer : ce serait la perte des données des utilisateurs.

---

## Partie 3 — Brancher l'API sur la base et le stockage

L'API 2.0 (Flask, `psycopg`, `boto3`) garde le fichier dans le bucket MinIO et sa description (nom, clé, taille, date) dans PostgreSQL. Elle crée la table et le bucket au démarrage.

```bash
docker compose up -d --build api
curl -s http://localhost:5000/sante
{"base":"ok","stockage":"ok"}
```

### Dépôt, liste, lecture

```bash
echo "Relevé de notes fictif" > releve.txt
curl -s -F "fichier=@releve.txt" http://localhost:5000/fichiers
{"cle":"38fbfd36f37b46efb96b0eaf822167e5-releve.txt","id":1,"nom":"releve.txt","taille":24}

curl -s -F "fichier=@/etc/hostname" http://localhost:5000/fichiers
{"cle":"ce5ff2bd05664b7db6958a4b3f96967a-hostname","id":2,"nom":"hostname","taille":11}

curl -s http://localhost:5000/fichiers
[{"cle":"38fbfd36...-releve.txt","depose_le":"2026-11-25T16:39:32.029094","id":1,"nom":"releve.txt","taille":24},
 {"cle":"ce5ff2bd...-hostname","depose_le":"2026-11-25T17:06:18.222782","id":2,"nom":"hostname","taille":11}]

curl -s http://localhost:5000/fichiers/1
Relevé de notes fictif

curl -s -F "autre=@releve.txt" http://localhost:5000/fichiers
{"erreur":"champ 'fichier' manquant"}
```

### Côté PostgreSQL

```bash
docker compose exec db psql -U app -d app -c "SELECT id, nom, taille FROM fichiers;"
```
```
 id |       nom        | taille
----+------------------+--------
  1 | releve.txt       |     24
  2 | hostname         |     11
  3 | 1000021118.jpg   |  21686
(3 rows)
```

### Image déposée depuis Windows

**PowerShell (hôte)**
```powershell
curl.exe -F "fichier=@C:\Users\Win\Desktop\1000021118.jpg" http://127.0.0.1:5000/fichiers
{"cle":"4f18e3cc8261404a91b87f41e7f0e3c8-1000021118.jpg","id":3,"nom":"1000021118.jpg","taille":21686}
```

L'image est ensuite consultable sur `http://127.0.0.1:5000/fichiers/3` et visible dans la console MinIO (bucket `fichiers`).

**Console MinIO** : le bucket `fichiers` contient les trois objets déposés (`releve.txt`, `hostname` et l'image).

![Console MinIO](captures/minio.jpg)

Cette première image étant très petite (21 Ko), une quatrième image plus grande a ensuite été déposée pour une capture plus lisible :

```powershell
curl.exe -F "fichier=@$env:USERPROFILE\Desktop\image3.jpg" http://127.0.0.1:5000/fichiers
{"cle":"956ffac2ec94455390239c7ca0275c4e-image3.jpg","id":4,"nom":"image3.jpg","taille":120483}
```

L'image est servie par l'API depuis le bucket, à l'adresse `http://127.0.0.1:5000/fichiers/4` :

![Image affichée par l'API (fichiers/4)](captures/photo.jpg)

### Questions

**Q1. Pourquoi un `uuid4` devant le nom du fichier ?**
Il rend chaque clé unique dans le bucket. Sans lui, deux fichiers `photo.jpg` déposés par deux étudiants auraient la même clé : le second écraserait le premier, on perdrait des données et la base pointerait vers un contenu qui n'est pas le bon.

**Q2. Que trouve-t-on dans PostgreSQL et dans MinIO ?**
Pour un même fichier, PostgreSQL contient les métadonnées (nom, clé, taille, date) et MinIO contient le contenu du fichier. On ne stocke pas les fichiers directement dans la base parce qu'elle est conçue pour des données structurées : y mettre des fichiers volumineux la gonflerait, la ralentirait et rendrait les sauvegardes plus lourdes. Le stockage objet est fait pour de gros fichiers, à faible coût et très scalable.

**Q3. Passer de MinIO à Amazon S3.**
Dans le code, **aucune ligne** ne change, car l'API ne parle qu'à l'API S3 via `boto3`. Dans le fichier Compose, il suffit de modifier les variables : `S3_ENDPOINT` (supprimé pour utiliser le point d'accès AWS par défaut), `S3_ACCESS_KEY`, `S3_SECRET_KEY` et `S3_BUCKET`. Le service `minio` devient inutile et peut être retiré.

**Q4. Pourquoi `initialiser()` attend-elle les services ?**
Parce que `depends_on` garantit seulement l'ordre de démarrage des conteneurs. MinIO est seulement `started` (sans healthcheck) : l'API peut démarrer alors qu'il n'accepte pas encore de connexions. La fonction `initialiser()` réessaie jusqu'à 30 fois, ce qui rend l'API robuste face à ce délai.

---

## Partie 4 — Sortir les secrets et nettoyer

```bash
cat > .env <<'EOF'
POSTGRES_PASSWORD=app_mdp
MINIO_ROOT_PASSWORD=tp3-secret-123
EOF
chmod 600 .env
echo ".env" >> .gitignore

sed -i 's/app_mdp/${POSTGRES_PASSWORD}/g; s/tp3-secret-123/${MINIO_ROOT_PASSWORD}/g' docker-compose.yml
grep -n 'PASSWORD\|SECRET\|DATABASE_URL' docker-compose.yml
```
```
7:      DATABASE_URL: postgresql://app:${POSTGRES_PASSWORD}@db:5432/app
10:     S3_SECRET_KEY: ${MINIO_ROOT_PASSWORD}
22:     POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
38:     MINIO_ROOT_PASSWORD: ${MINIO_ROOT_PASSWORD}
```

```bash
docker compose config | grep -n 'PASSWORD\|SECRET'
```
```
20:      S3_SECRET_KEY: tp3-secret-123
31:      POSTGRES_PASSWORD: app_mdp
55:      MINIO_ROOT_PASSWORD: tp3-secret-123
```

```bash
docker compose up -d
curl -s http://localhost:5000/sante
{"base":"ok","stockage":"ok"}

docker compose down
docker volume ls | grep tp3
local     tp3_db-data
local     tp3_minio-data
```

L'application a été arrêtée en **gardant les volumes** pour la séance 6.

### Questions

**Q1. Que montre `docker compose config` ?**
Il affiche les **vraies valeurs** (`app_mdp`, `tp3-secret-123`) à la place des `${...}`. Le secret n'a donc pas disparu de la machine : il est toujours dans le fichier `.env` et dans les variables d'environnement des conteneurs. Il a seulement disparu du dépôt Git, puisque `.env` est listé dans `.gitignore`.

**Q2. Deux solutions plus sûres qu'un fichier `.env`.**
1. Un **gestionnaire de secrets managé** (AWS Secrets Manager, Azure Key Vault, Google Secret Manager) : les secrets sont chiffrés, leur accès est contrôlé et journalisé, et ils peuvent être renouvelés automatiquement.
2. Des **identités managées ou rôles IAM** : l'application obtient ses droits d'accès aux services (base, stockage) sans qu'aucun mot de passe soit stocké.

---

## Contenu du dépôt

- `TP3.md` (ce compte rendu)
- `docker-compose.yml`
- `.gitignore`
- `api/` (`app.py`, `requirements.txt`, `Dockerfile`, `.dockerignore`)
- **sans** le fichier `.env`
